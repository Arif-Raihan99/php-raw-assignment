

    <script src="assets/include/js/jquery-3.6.0.min.js"></script>
    <script src="assets/include/js/bootstrap.bundle.js"></script>
</body>
</html>
